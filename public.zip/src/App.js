import "./App.css";
import Todo from "./components/Todo";

function App() {
  return (
    <div className="container">
      <Todo />
    </div>
  );
}

export default App;
